#include <stdio.h>
#include <cs50.h>

int main(void){
int age = get_int("What's your age?");
printf("%i, how beautiful age you are!",age);

}
