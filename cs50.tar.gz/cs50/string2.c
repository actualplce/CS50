#include <stdio.h> //standard input output
#include <cs50.h>

int main(void){
string animal= get_string("What's your favorite animal?\n");
printf("lovely, %s\n", animal); //answer변수는 string타입.(%s)
}
